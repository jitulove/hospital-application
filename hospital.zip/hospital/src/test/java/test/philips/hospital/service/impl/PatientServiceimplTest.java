package test.philips.hospital.service.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import test.philips.hospital.model.Examination;
import test.philips.hospital.model.Patient;
import test.philips.hospital.repository.ExaminationRepository;
import test.philips.hospital.repository.PatientRepository;
import test.philips.hospital.util.Util;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PatientServiceimplTest {

	@InjectMocks
	PatientServiceimpl patientServiceimpl;

	@Mock
	PatientRepository patientRepository;

	@Mock
	ExaminationRepository examinationRepository;

	@Test
	public void testComputeAge() {

		Patient patient = new Patient();
		patient.setDateOfBirth(Util.toDateFromStringDate("04-03-1987"));
		Optional<Patient> patientOptional = Optional.of(patient);

		when(patientRepository.findById(1L)).thenReturn(patientOptional);
		Double age = patientServiceimpl.computeAge(1L);
		assertNotNull(age);		
	}

	@Test
	public void testComputeBmi() {
		Examination examination = new Examination();
		examination.setExaminationId(1L);
		examination.setHeight(5.7);
		examination.setWeight(81.2);
		Optional<Examination> examinationOptional = Optional.of(examination);
		when(examinationRepository.findById(1L)).thenReturn(examinationOptional);
		Double bmi = patientServiceimpl.computeBmi(1L);
		assertNotNull(bmi);
	}

}
