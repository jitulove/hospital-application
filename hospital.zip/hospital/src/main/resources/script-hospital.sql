For MySQL:

ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'password';

create user 'user'@'localhost' identified by 'password';
create database hospitaldb;
grant all on hospitaldb.* to 'user'@'localhost';



Database commands:

drop table examination;
drop table patient;
drop table institution;

create table examination (examination_id bigint not null, description varchar(255), exam_date datetime, height double precision, name varchar(255), weight double precision, patient_id bigint, primary key (examination_id));
create table institution (institution_id bigint not null, description varchar(255), name varchar(255), primary key (institution_id));
create table patient (patient_id bigint not null, date_of_birth datetime, gender varchar(255), name varchar(255), institution_id bigint, primary key (patient_id));

Insert Commands:

insert into hospitaldb.institution (institution_id,description,name) 
values (1,"Sakra Bangalore","Sakra Hospital");
insert into hospitaldb.institution (institution_id,description,name) 
values (2,"Apollo Bangalore","Apollo Hospital");
insert into hospitaldb.institution (institution_id,description,name) 
values (3,"Manipal Bangalore","Apollo Hospital");

insert into hospitaldb.patient(patient_id,name,gender,date_of_birth,institution_id) 
values (1,"Joe","Male","1991-03-04 00:00:00",1);
insert into hospitaldb.patient(patient_id,name,gender,date_of_birth,institution_id) 
values (2,"Ray","Male","1995-03-04 00:00:00",1);
insert into hospitaldb.patient(patient_id,name,gender,date_of_birth,institution_id) 
values (3,"Chris","Male","1989-06-04 00:00:00",2);
insert into hospitaldb.patient(patient_id,name,gender,date_of_birth,institution_id) 
values (4,"Tony","Male","1981-03-04 00:00:00",2);

insert into hospitaldb.examination(examination_id,description,exam_date,height,name,weight,patient_id)
values(1,"LFT","2018-05-04 00:00:00",5.11,"Joe",65,1);
insert into hospitaldb.examination(examination_id,description,exam_date,height,name,weight,patient_id)
values(2,"CBC","2018-05-04 00:00:00",5.1,"Ray",69,2);
insert into hospitaldb.examination(examination_id,description,exam_date,height,name,weight,patient_id)
values(3,"WBC","2018-05-04 00:00:00",5.7,"Chris",65,3);
insert into hospitaldb.examination(examination_id,description,exam_date,height,name,weight,patient_id)
values(4,"LFT","2018-05-04 00:00:00",5.11,"Joe",65,1);
insert into hospitaldb.examination(examination_id,description,exam_date,height,name,weight,patient_id)
values(5,"D3","2018-05-04 00:00:00",6.1,"Tony",78,4);






