angular.module('hospitalApp', [])
.controller('hospital', function($scope, $http) {
    $http.get('http://localhost:8080/institution/all').
        then(function(response) {
        	console.log(response.data);
            $scope.institutionList = response.data;
        });
});