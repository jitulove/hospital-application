package test.philips.hospital.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import test.philips.hospital.dto.ExaminationDTO;
import test.philips.hospital.model.Examination;
import test.philips.hospital.model.Patient;
import test.philips.hospital.repository.ExaminationRepository;
import test.philips.hospital.repository.PatientRepository;
import test.philips.hospital.service.ExaminationService;
import test.philips.hospital.util.Util;

@Service
public class ExaminationServiceImpl implements ExaminationService {

	@Autowired
	PatientRepository patientRepository;

	@Autowired
	ExaminationRepository examinationRepository;

	@Override
	public Examination add(ExaminationDTO examinationDto) {
		if (null != examinationDto) {
			Examination examination = new Examination();
			examination.setExamDate(Util.toDateFromStringDate(examinationDto.getExamDate()));
			examination.setDescription(examinationDto.getDescription());
			examination.setName(examinationDto.getName());
			examination.setHeight(examinationDto.getHeight());
			examination.setWeight(examinationDto.getWeight());
			if (null != examinationDto.getPatientId()) {
				Optional<Patient> optionalPatient = patientRepository.findById(examinationDto.getPatientId());
				if (optionalPatient.isPresent()) {
					examination.setPatient(optionalPatient.get());
				}
			}
			return examinationRepository.save(examination);
		}
		return null;
	}

	@Override
	public List<Examination> getAllExaminationByPatientId(Long patientId) {
		return examinationRepository.getAllExaminationByPatientId(patientId);
	}

}
