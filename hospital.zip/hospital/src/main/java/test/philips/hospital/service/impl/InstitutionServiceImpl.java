package test.philips.hospital.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import test.philips.hospital.dto.InstitutionDTO;
import test.philips.hospital.model.Institution;
import test.philips.hospital.repository.InstitutionRepository;
import test.philips.hospital.service.InstitutionService;

@Service
public class InstitutionServiceImpl implements InstitutionService {

	@Autowired
	InstitutionRepository institutionRepository;

	@Override
	public Institution add(InstitutionDTO institutionDto) {
		if (null != institutionDto) {
			Institution institution = new Institution();
			institution.setDescription(institutionDto.getDescription());
			institution.setName(institutionDto.getName());
			return institutionRepository.save(institution);
		}
		return null;
	}

	@Override
	public void remove(Long id) {
		institutionRepository.deleteById(id);
	}

	@Override
	public Institution update(InstitutionDTO institutionDto) {
		if (null != institutionDto && null != institutionDto.getInstitutionId()) {
			Optional<Institution> institution = institutionRepository.findById(institutionDto.getInstitutionId());
			if (institution.isPresent()) {
				Institution institutionEntity = institution.get();
				institutionEntity.setDescription(institutionDto.getDescription());
				institutionEntity.setName(institutionDto.getName());
				return institutionRepository.save(institutionEntity);
			}
		}
		return null;
	}

	@Override
	public Optional<Institution> get(Long id) {
		return institutionRepository.findById(id);
	}

	@Override
	public List<Institution> getAll() {
		return institutionRepository.findAll();
	}
}
