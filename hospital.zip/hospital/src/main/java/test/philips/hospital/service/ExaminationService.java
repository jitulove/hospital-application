package test.philips.hospital.service;

import java.util.List;

import test.philips.hospital.dto.ExaminationDTO;
import test.philips.hospital.model.Examination;

public interface ExaminationService {

	Examination add(ExaminationDTO examinationDto);
	
	List<Examination> getAllExaminationByPatientId(Long patientId);

}
