package test.philips.hospital.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import test.philips.hospital.dto.PatientDTO;
import test.philips.hospital.model.Patient;
import test.philips.hospital.service.PatientService;

@RestController
@RequestMapping(value="/patient")
public class PatientController {

	@Autowired
	PatientService patientService;

	@PostMapping("/add")
	public ResponseEntity<Patient> addPatient(@RequestBody PatientDTO patientDto) {
		Patient patient = patientService.add(patientDto);
		if (patient == null) {
			return new ResponseEntity<Patient>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Patient>(patient, HttpStatus.OK);
	}

	@PostMapping("/update")
	public ResponseEntity<Patient> updatePatient(@RequestBody PatientDTO patientDto) {
		Patient patient = patientService.update(patientDto);
		if (patient == null) {
			return new ResponseEntity<Patient>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Patient>(patient, HttpStatus.OK);
	}

	@DeleteMapping("/remove")
	public void removePatient(Long id) {
		patientService.remove(id);
	}

	@GetMapping("/get")
	public ResponseEntity<Optional<Patient>> getPatient(@RequestParam Long id) {
		Optional<Patient> optional = patientService.get(id);
		if (optional == null) {
			return new ResponseEntity<Optional<Patient>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Optional<Patient>>(optional, HttpStatus.OK);
	}

	@GetMapping("/all")
	public ResponseEntity<List<Patient>> getAllPatient() {
		List<Patient> list = patientService.getAll();
		if (list == null) {
			return new ResponseEntity<List<Patient>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Patient>>(list, HttpStatus.OK);
	}

	@GetMapping("/age")
	public ResponseEntity<Double> computeAge(@RequestParam Long id) {
		Double age = patientService.computeAge(id);
		if (age == null) {
			return new ResponseEntity<Double>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Double>(age, HttpStatus.OK);
	}

}
