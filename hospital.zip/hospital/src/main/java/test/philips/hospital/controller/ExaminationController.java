package test.philips.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import test.philips.hospital.dto.ExaminationDTO;
import test.philips.hospital.model.Examination;
import test.philips.hospital.service.ExaminationService;
import test.philips.hospital.service.PatientService;

@RestController
@RequestMapping(value = "/examination")
public class ExaminationController {

	@Autowired
	PatientService patientService;

	@Autowired
	ExaminationService examinationService;

	@GetMapping("/bmi")
	public ResponseEntity<Double> computeAge(@RequestParam Long examinationId) {
		Double bmi = patientService.computeBmi(examinationId);
		if (bmi == null) {
			return new ResponseEntity<Double>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Double>(bmi, HttpStatus.OK);
	}

	@PostMapping("/add")
	public ResponseEntity<Examination> addExamination(@RequestBody ExaminationDTO examinationDto) {
		Examination examination = examinationService.add(examinationDto);
		if (examination == null) {
			return new ResponseEntity<Examination>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Examination>(examination, HttpStatus.OK);
	}

	@GetMapping("/get/patientid")
	public ResponseEntity<List<Examination>> getByPatientId(@RequestParam Long patientId) {
		List<Examination> allExaminationByPatientId = examinationService.getAllExaminationByPatientId(patientId);
		if (allExaminationByPatientId == null) {
			return new ResponseEntity<List<Examination>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Examination>>(allExaminationByPatientId, HttpStatus.OK);
	}

}
