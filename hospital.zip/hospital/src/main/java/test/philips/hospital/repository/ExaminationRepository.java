package test.philips.hospital.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import test.philips.hospital.model.Examination;

@Repository
public interface ExaminationRepository extends JpaRepository<Examination, Long> {

	@Query("select e from Examination e where e.patient.patientId = :patientId")
	List<Examination> getAllExaminationByPatientId(@Param("patientId") Long patientId);

}
