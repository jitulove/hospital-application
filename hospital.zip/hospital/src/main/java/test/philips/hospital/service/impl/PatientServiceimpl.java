package test.philips.hospital.service.impl;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import test.philips.hospital.dto.PatientDTO;
import test.philips.hospital.model.Examination;
import test.philips.hospital.model.Institution;
import test.philips.hospital.model.Patient;
import test.philips.hospital.repository.ExaminationRepository;
import test.philips.hospital.repository.InstitutionRepository;
import test.philips.hospital.repository.PatientRepository;
import test.philips.hospital.service.PatientService;
import test.philips.hospital.util.Util;

@Service
public class PatientServiceimpl implements PatientService {	

	@Autowired
	PatientRepository patientRepository;
	
	@Autowired
	ExaminationRepository examinationRepository;
	
	@Autowired
	InstitutionRepository institutionRepository;

	@Override
	public Patient add(PatientDTO patientDto) {
		if (null != patientDto) {
			Patient patient = new Patient();
			patient.setDateOfBirth(Util.toDateFromStringDate(patientDto.getDateOfBirth()));
			patient.setGender(patientDto.getGender());
			patient.setName(patientDto.getName());
			if(null != patientDto.getInstitutionId()) {
				Optional<Institution> institutionOptional = institutionRepository.findById(patientDto.getInstitutionId());
				if(institutionOptional.isPresent()) {
					patient.setInstitution(institutionOptional.get());
				}
			}
			return patientRepository.save(patient);
		}
		return null;
	}

	@Override
	public void remove(Long id) {
		patientRepository.deleteById(id);

	}

	@Override
	public Patient update(PatientDTO patientDto) {
		if (null != patientDto && null != patientDto.getPatientId()) {
			Optional<Patient> patient = patientRepository.findById(patientDto.getPatientId());
			if (patient.isPresent()) {
				Patient patientEntity = patient.get();
				patientEntity.setDateOfBirth(Util.toDateFromStringDate(patientDto.getDateOfBirth()));
				patientEntity.setGender(patientDto.getGender());
				patientEntity.setName(patientDto.getName());
				if(null != patientDto.getInstitutionId()) {
					Optional<Institution> institutionOptional = institutionRepository.findById(patientDto.getInstitutionId());
					if(institutionOptional.isPresent()) {
						patientEntity.setInstitution(institutionOptional.get());
					}
				}

				return patientRepository.save(patientEntity);
			}
		}
		return null;
	}

	@Override
	public Optional<Patient> get(Long id) {
		return patientRepository.findById(id);
	}

	@Override
	public List<Patient> getAll() {
		return patientRepository.findAll();
	}

	@Override
	public Double computeAge(Long id) {
		if (null != id) {
			Optional<Patient> patient = patientRepository.findById(id);
			if (patient.isPresent()) {
				Patient patientEntity = patient.get();
				Date dateOfBirth = patientEntity.getDateOfBirth();
				LocalDateTime dob = Util.toLocalDateTimeFromDate(dateOfBirth);
				return ChronoUnit.MONTHS.between(dob, LocalDateTime.now()) / 12.0;
			}
		}
		return null;
	}

	@Override
	public Double computeBmi(Long examinationId) {
		if (null != examinationId) {
			Optional<Examination> examination = examinationRepository.findById(examinationId);
			if (examination.isPresent()) {
				Examination examinationEntity = examination.get();
				Double height = examinationEntity.getHeight();
				Double weight = examinationEntity.getWeight();
				return weight / (height * height);
			}
		}
		return null;
	}
}
