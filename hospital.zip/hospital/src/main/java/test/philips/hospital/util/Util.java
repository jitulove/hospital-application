package test.philips.hospital.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Util {

	private static final Logger LOGGER = LoggerFactory.getLogger(Util.class);

	private Util() {
		// private constructor
	}

	public static Date toDateFromStringDate(String date) {
		try {
			return new SimpleDateFormat("dd-MM-yyyy").parse(date);
		} catch (ParseException e) {
			LOGGER.info(e.getMessage());
		}
		return null;
	}

	public static LocalDateTime toLocalDateTimeFromDate(Date date) {
		if (null != date) {
			return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
		}
		return null;
	}

}
