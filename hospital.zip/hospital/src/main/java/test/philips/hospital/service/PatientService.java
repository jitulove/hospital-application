package test.philips.hospital.service;

import java.util.List;
import java.util.Optional;

import test.philips.hospital.dto.PatientDTO;
import test.philips.hospital.model.Patient;

public interface PatientService {

	public Patient add(PatientDTO patientDto);

	public void remove(Long id);

	public Patient update(PatientDTO patientDto);

	public Optional<Patient> get(Long id);

	public List<Patient> getAll();
	
	Double computeAge(Long id);
	
	Double computeBmi(Long examinationId);

}
