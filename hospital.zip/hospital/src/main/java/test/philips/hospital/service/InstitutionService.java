package test.philips.hospital.service;

import java.util.List;
import java.util.Optional;

import test.philips.hospital.dto.InstitutionDTO;
import test.philips.hospital.model.Institution;

public interface InstitutionService {

	public Institution add(InstitutionDTO institutionDto);

	public void remove(Long id);

	public Institution update(InstitutionDTO institutionDto);

	public Optional<Institution> get(Long id);

	public List<Institution> getAll();

}
