package test.philips.hospital.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import test.philips.hospital.dto.InstitutionDTO;
import test.philips.hospital.model.Institution;
import test.philips.hospital.service.InstitutionService;

@RestController
@RequestMapping(value="/institution")
public class InstitutionController {

	@Autowired
	InstitutionService institutionService;

	@PostMapping("/add")
	public ResponseEntity<Institution> addInstitution(@RequestBody InstitutionDTO institutionDto) {
		Institution institution = institutionService.add(institutionDto);
		if (institution == null) {
			return new ResponseEntity<Institution>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Institution>(institution, HttpStatus.OK);
	}

	@PostMapping("/update")
	public ResponseEntity<Institution> updateInstitution(@RequestBody InstitutionDTO institutionDto) {
		Institution institution = institutionService.update(institutionDto);
		if (institution == null) {
			return new ResponseEntity<Institution>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Institution>(institution, HttpStatus.OK);
	}

	@DeleteMapping(value = "/remove")
	public void removeInstitution(Long id) {
		institutionService.remove(id);
	}

	@GetMapping("/get")
	public ResponseEntity<Optional<Institution>> getInstitution(@RequestParam Long id) {
		Optional<Institution> optional = institutionService.get(id);
		if (optional == null) {
			return new ResponseEntity<Optional<Institution>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Optional<Institution>>(optional, HttpStatus.OK);
	}

	@GetMapping("/all")
	public ResponseEntity<List<Institution>> getAllInstitution() {
		List<Institution> list = institutionService.getAll();
		if (list == null) {
			return new ResponseEntity<List<Institution>>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Institution>>(list, HttpStatus.OK);
	}

}
